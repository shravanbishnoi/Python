# def incr(x):
#     return x+1

# if __name__=='__main__':
#     print(incr(5))

def last_name_first(name):
    #finish
    last_name_first("Shravan")